import { OneProfileHome } from '@/components/oneprofile/oneprofile-home'

export default function Page() {
  return <OneProfileHome />
}
