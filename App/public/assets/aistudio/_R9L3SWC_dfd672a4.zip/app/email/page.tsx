import type { Metadata } from 'next'
import { MailApp } from '@/components/email/mail-app'

export const metadata: Metadata = { title: 'Tiwlo Mail — Inbox' }

export default function Page() {
  return <MailApp />
}
