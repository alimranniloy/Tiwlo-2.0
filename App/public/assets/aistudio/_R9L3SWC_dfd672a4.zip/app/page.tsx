import { LandingFooter } from '@/components/landing/footer'
import { LandingNavbar } from '@/components/landing/navbar'
import {
  CloudSection,
  CommerceSection,
  CtaSection,
  FaqSection,
  HeroSection,
  ProductsSection,
  WhySection,
} from '@/components/landing/sections'

export default function Page() {
  return (
    <>
      <LandingNavbar />
      <main>
        <HeroSection />
        <ProductsSection />
        <CloudSection />
        <CommerceSection />
        <WhySection />
        <FaqSection />
        <CtaSection />
      </main>
      <LandingFooter />
    </>
  )
}
