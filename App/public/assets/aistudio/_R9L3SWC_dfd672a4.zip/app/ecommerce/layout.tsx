import type { Metadata } from 'next'
import { DashboardShell } from '@/components/shell/dashboard-shell'

export const metadata: Metadata = { title: 'Store Dashboard — Tiwlo' }

export default function Layout({ children }: { children: React.ReactNode }) {
  return <DashboardShell variant="ecommerce">{children}</DashboardShell>
}
