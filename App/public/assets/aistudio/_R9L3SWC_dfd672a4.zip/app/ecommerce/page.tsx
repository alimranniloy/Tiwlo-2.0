import { StoreOverview } from '@/components/ecommerce/store-overview'

export default function Page() {
  return <StoreOverview />
}
