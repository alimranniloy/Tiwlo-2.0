import type { Metadata } from 'next'
import { DashboardShell } from '@/components/shell/dashboard-shell'

export const metadata: Metadata = { title: 'Cloud Dashboard — Tiwlo' }

export default function Layout({ children }: { children: React.ReactNode }) {
  return <DashboardShell variant="cloud">{children}</DashboardShell>
}
