import { CloudOverview } from '@/components/cloud/cloud-overview'

export default function Page() {
  return <CloudOverview />
}
