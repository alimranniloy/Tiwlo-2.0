import {
  ArrowUpRight,
  Check,
  Cloud,
  Copy,
  Eye,
  Fingerprint,
  Globe,
  HardDrive,
  Lock,
  Mail,
  MoreHorizontal,
  Nfc,
  Pencil,
  Phone,
  Plus,
  X,
} from 'lucide-react'
import { TrendArea } from '@/components/shell/charts'
import { PageHeader, Panel, PillButton, StatCard, StatusPill } from '@/components/shell/primitives'

const views = [
  { label: 'Mon', views: 120 },
  { label: 'Tue', views: 180 },
  { label: 'Wed', views: 150 },
  { label: 'Thu', views: 240 },
  { label: 'Fri', views: 310 },
  { label: 'Sat', views: 280 },
  { label: 'Sun', views: 360 },
]

const templates = [
  { name: 'Minimal', desc: 'Clean & simple', tone: 'bg-muted' },
  { name: 'Business', desc: 'Corporate site', tone: 'bg-ink text-ink-foreground' },
  { name: 'Portfolio', desc: 'Showcase your work', tone: 'bg-primary text-primary-foreground' },
  { name: 'Creative Portfolio', desc: 'Modern & premium design', tone: 'bg-secondary' },
]

const subdomains = [
  { name: 'rahim.uids.app', status: 'Live', ssl: true },
  { name: 'rahim-studio.uids.app', status: 'Pending', ssl: false },
]

const freePlan = [
  { label: 'Free subdomain', ok: true },
  { label: 'Static website hosting', ok: true },
  { label: 'SSL certificate', ok: true },
  { label: 'No Node.js backend', ok: false },
]

export function OneProfileHome() {
  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        eyebrow="UIDs · OneProfile"
        title="Your Identity, Your Website."
        description="Manage your personal website, free .uids.app subdomain, cloud hosting and NFC business card from one place."
        actions={
          <>
            <PillButton variant="outline">
              <Eye className="size-4" aria-hidden="true" /> Preview
            </PillButton>
            <PillButton>
              <Pencil className="size-4" aria-hidden="true" /> Edit Website
            </PillButton>
          </>
        }
      />

      <div className="grid gap-6 lg:grid-cols-5">
        <section className="relative overflow-hidden rounded-3xl bg-ink p-6 text-ink-foreground sm:p-8 lg:col-span-3">
          <div className="relative z-10 flex flex-col gap-6 sm:flex-row sm:items-center">
            <div className="flex size-24 shrink-0 items-center justify-center rounded-full bg-primary text-3xl font-bold text-primary-foreground ring-4 ring-white/10">
              RH
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <StatusPill status="Live" />
                <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-semibold">Free Plan</span>
              </div>
              <p className="mt-3 text-sm text-white/60">{"Hi, I'm"}</p>
              <h2 className="text-3xl font-bold tracking-tight">Rahim Hossain</h2>
              <p className="mt-1 text-white/70">Designer & Developer</p>
              <div className="mt-4 flex items-center gap-2 rounded-full bg-white/5 py-1.5 pl-4 pr-1.5 ring-1 ring-white/10">
                <Globe className="size-4 text-primary" aria-hidden="true" />
                <span className="flex-1 truncate font-mono text-sm">rahim.uids.app</span>
                <button
                  type="button"
                  aria-label="Copy link"
                  className="flex size-8 items-center justify-center rounded-full bg-white/10 hover:bg-white/15"
                >
                  <Copy className="size-3.5" />
                </button>
              </div>
            </div>
          </div>
          <div className="relative z-10 mt-6 flex flex-wrap gap-2">
            {[
              { icon: Mail, label: 'Contact Me' },
              { icon: Phone, label: 'Call' },
              { icon: ArrowUpRight, label: 'Showcase' },
            ].map((b) => (
              <span
                key={b.label}
                className="inline-flex h-9 items-center gap-2 rounded-full bg-white/10 px-4 text-xs font-bold ring-1 ring-white/10"
              >
                <b.icon className="size-3.5" aria-hidden="true" /> {b.label}
              </span>
            ))}
          </div>
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-36 -top-36 size-[340px] rounded-full border-[44px] border-primary/90"
          />
        </section>

        <div className="grid grid-cols-2 gap-4 lg:col-span-2">
          <StatCard label="Profile Views" value="1,640" hint="+24% this week" icon={Eye} tone="primary" />
          <StatCard label="Subdomains" value="2" hint="1 live · 1 pending" icon={Fingerprint} />
          <StatCard label="Storage Used" value="24%" hint="120 MB of 500 MB" icon={HardDrive} />
          <StatCard label="Active Template" value="Minimal" hint="Clean & simple" icon={Globe} />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel id="analytics" title="Profile Views" className="lg:col-span-2">
          <TrendArea data={views} keys={[{ key: 'views', color: '#1ed760', label: 'Views' }]} height={240} />
        </Panel>
        <Panel title="Free Plan">
          <ul className="flex flex-col gap-3">
            {freePlan.map((f) => (
              <li key={f.label} className="flex items-center gap-3 text-sm">
                <span
                  className={
                    f.ok
                      ? 'flex size-6 items-center justify-center rounded-full bg-primary text-primary-foreground'
                      : 'flex size-6 items-center justify-center rounded-full bg-muted text-muted-foreground'
                  }
                >
                  {f.ok ? <Check className="size-3.5" strokeWidth={3} /> : <X className="size-3.5" strokeWidth={3} />}
                </span>
                <span className={f.ok ? 'font-medium' : 'text-muted-foreground'}>{f.label}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 rounded-2xl bg-muted p-4">
            <p className="text-sm font-bold">Upgrade Now</p>
            <p className="mt-1 text-xs text-muted-foreground">Custom domain · More storage · Node.js support · Premium templates</p>
            <PillButton className="mt-3 h-9 px-4 text-xs">{'Upgrade Now ->'}</PillButton>
          </div>
        </Panel>
      </div>

      <Panel
        id="templates"
        title="Popular Templates"
        action={<span className="text-xs font-bold">See all</span>}
      >
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {templates.map((t, i) => (
            <div key={t.name} className="group">
              <div className={`relative flex aspect-[4/3] flex-col justify-end overflow-hidden rounded-2xl p-4 ${t.tone}`}>
                <div className="absolute inset-x-4 top-4 flex flex-col gap-1.5 opacity-60">
                  <span className="h-2 w-1/2 rounded-full bg-current" />
                  <span className="h-2 w-3/4 rounded-full bg-current opacity-50" />
                  <span className="h-2 w-2/3 rounded-full bg-current opacity-30" />
                </div>
                {i === 0 && (
                  <span className="w-fit rounded-full bg-ink px-2.5 py-1 text-[10px] font-bold text-ink-foreground">
                    Active Template
                  </span>
                )}
              </div>
              <p className="mt-3 text-sm font-bold">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.desc}</p>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel
          id="subdomains"
          title="Subdomains"
          action={
            <PillButton className="h-9 px-4 text-xs">
              <Plus className="size-3.5" aria-hidden="true" /> Create Subdomain
            </PillButton>
          }
          className="lg:col-span-2"
        >
          <ul className="flex flex-col gap-3">
            {subdomains.map((s) => (
              <li key={s.name} className="flex items-center gap-4 rounded-2xl bg-muted p-4">
                <span className="flex size-10 items-center justify-center rounded-full bg-background">
                  <Globe className="size-4" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-mono text-sm font-semibold">{s.name}</p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Lock className="size-3" aria-hidden="true" /> {s.ssl ? 'SSL active' : 'SSL pending'}
                  </p>
                </div>
                <StatusPill status={s.status} />
                <button
                  type="button"
                  aria-label={`More options for ${s.name}`}
                  className="flex size-8 items-center justify-center rounded-full hover:bg-background"
                >
                  <MoreHorizontal className="size-4" />
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-4 rounded-2xl border-2 border-dashed border-border p-5 text-center">
            <p className="text-sm font-bold">Get your free .uids.app</p>
            <p className="mt-1 text-xs text-muted-foreground">Claim a memorable subdomain for your profile.</p>
          </div>
        </Panel>

        <div className="flex flex-col gap-6">
          <Panel id="hosting">
            <div className="flex items-center gap-3">
              <span className="flex size-11 items-center justify-center rounded-full bg-primary/15 text-[#0f7a37]">
                <Cloud className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-bold">Cloud Hosting</p>
                <p className="text-xs text-muted-foreground">Link to our cloud or server</p>
              </div>
            </div>
            <PillButton variant="outline" className="mt-4 h-9 w-full justify-center text-xs">
              Connect Hosting
            </PillButton>
          </Panel>
          <section id="nfc" className="relative overflow-hidden rounded-3xl bg-primary p-6 text-primary-foreground">
            <Nfc className="size-8" aria-hidden="true" />
            <p className="mt-4 text-lg font-bold">NFC Business Card</p>
            <p className="mt-1 text-sm opacity-70">Tap to connect. Share your digital profile with a physical card.</p>
            <button
              type="button"
              className="mt-4 inline-flex h-9 items-center rounded-full bg-ink px-4 text-xs font-bold text-ink-foreground"
            >
              Order NFC Card
            </button>
          </section>
        </div>
      </div>
    </div>
  )
}
