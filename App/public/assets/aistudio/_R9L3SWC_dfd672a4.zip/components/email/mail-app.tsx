'use client'

import Link from 'next/link'
import { useState } from 'react'
import {
  Archive,
  ArrowLeft,
  Bell,
  ChevronDown,
  FileText,
  Flag,
  Inbox,
  LayoutGrid,
  Mail,
  Menu,
  MoreHorizontal,
  Paperclip,
  Pencil,
  Pin,
  Printer,
  RefreshCw,
  Reply,
  ReplyAll,
  Search,
  Send,
  ShieldAlert,
  Star,
  Tag,
  Trash2,
  Undo2,
  X,
} from 'lucide-react'
import { Logo } from '@/components/brand/logo'
import { cn } from '@/lib/utils'

const folders = [
  { label: 'Inbox', icon: Inbox, count: 12 },
  { label: 'Sent Items', icon: Send },
  { label: 'Drafts', icon: FileText, count: 2 },
  { label: 'Flagged', icon: Flag },
  { label: 'Archive', icon: Archive },
  { label: 'Junk Email', icon: ShieldAlert },
  { label: 'Deleted Items', icon: Trash2 },
]

const categories = [
  { label: 'Finance', color: 'bg-[#1ed760]' },
  { label: 'Projects', color: 'bg-sky-500' },
  { label: 'Personal', color: 'bg-amber-400' },
  { label: 'Urgent', color: 'bg-red-500' },
]

const emails = [
  {
    id: 1,
    from: 'Tiwlo Billing',
    email: 'billing@tiwlo.com',
    subject: 'Invoice INV-2026-011 has been paid',
    preview: 'Thank you! Your payment for the Growth plan has been received and applied to your workspace.',
    time: '9:42 AM',
    unread: true,
    category: 'Finance',
    attachment: true,
  },
  {
    id: 2,
    from: 'Ayesha Rahman',
    email: 'ayesha@northwind.co',
    subject: 'Storefront theme review — round 2',
    preview: 'Hey! I went through the new homepage banner and checkout flow. A few notes below on spacing…',
    time: '8:15 AM',
    unread: true,
    category: 'Projects',
    starred: true,
  },
  {
    id: 3,
    from: 'Droplet Monitor',
    email: 'alerts@tiwlo.cloud',
    subject: 'web-prod-01 CPU above 80%',
    preview: 'Your droplet web-prod-01 in Frankfurt exceeded the CPU threshold for 10 minutes.',
    time: 'Yesterday',
    unread: false,
    category: 'Urgent',
  },
  {
    id: 4,
    from: 'TiwiMart Orders',
    email: 'orders@tiwimart.com',
    subject: 'New order #1048 — 3 items',
    preview: 'A new order was placed via POS. Classic Cotton Tee ×2, Leather Card Wallet ×1.',
    time: 'Yesterday',
    unread: false,
  },
  {
    id: 5,
    from: 'Nusrat Jahan',
    email: 'nusrat@gmail.com',
    subject: 'Weekend plans?',
    preview: 'Are we still on for Saturday? Let me know if the time works for you.',
    time: 'Mon',
    unread: false,
    category: 'Personal',
  },
  {
    id: 6,
    from: 'UIDs Team',
    email: 'hello@uids.app',
    subject: 'Your subdomain rahim.uids.app is live',
    preview: 'Congratulations! SSL has been provisioned and your OneProfile site is now publicly reachable.',
    time: 'Sun',
    unread: false,
  },
]

const categoryColor = Object.fromEntries(categories.map((c) => [c.label, c.color]))

function initials(name: string) {
  return name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
}

function FolderSidebar({ onClose }: { onClose?: () => void }) {
  return (
    <div className="flex h-full flex-col gap-6 bg-ink p-4 text-ink-foreground">
      <div className="flex items-center justify-between px-2 pt-2">
        <Logo inverted href="/email" suffix="Mail" />
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="flex size-8 items-center justify-center rounded-full text-white/70 hover:bg-white/10"
          >
            <X className="size-4" />
          </button>
        )}
      </div>
      <button
        type="button"
        title="Compose New Mail (Ctrl + N)"
        className="flex h-11 items-center justify-center gap-2 rounded-full bg-primary text-sm font-bold text-primary-foreground transition hover:bg-primary/85"
      >
        <Pencil className="size-4" aria-hidden="true" /> New mail
      </button>

      <nav aria-label="Mail folders" className="flex flex-1 flex-col gap-6 overflow-y-auto">
        <div>
          <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-widest text-white/40">Folders</p>
          <ul className="flex flex-col gap-0.5">
            {folders.map((f, i) => (
              <li key={f.label}>
                <button
                  type="button"
                  aria-current={i === 0 ? 'page' : undefined}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition',
                    i === 0 ? 'bg-white text-ink' : 'text-white/65 hover:bg-white/5 hover:text-white',
                  )}
                >
                  <f.icon className="size-[18px]" aria-hidden="true" />
                  <span className="flex-1 text-left">{f.label}</span>
                  {f.count && (
                    <span
                      className={cn(
                        'rounded-full px-2 py-0.5 text-[10px] font-bold',
                        i === 0 ? 'bg-ink text-ink-foreground' : 'bg-white/10',
                      )}
                    >
                      {f.count}
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-widest text-white/40">Categories</p>
          <ul className="flex flex-col gap-0.5">
            {categories.map((c) => (
              <li key={c.label}>
                <button
                  type="button"
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-white/65 transition hover:bg-white/5 hover:text-white"
                >
                  <span className={cn('size-2.5 rounded-full', c.color)} aria-hidden="true" />
                  {c.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      <div className="flex items-center gap-3 rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
        <span className="flex size-9 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
          RH
        </span>
        <div className="min-w-0">
          <p className="text-[11px] text-white/50">Signed in as</p>
          <p className="truncate text-sm font-semibold">rahim@tiwlo.com</p>
        </div>
      </div>
    </div>
  )
}

const ribbon = [
  { label: 'Delete', icon: Trash2 },
  { label: 'Archive', icon: Archive },
  { label: 'Report Junk', icon: ShieldAlert },
  { label: 'Move to', icon: ChevronDown },
  { label: 'Categorize', icon: Tag },
  { label: 'Pin', icon: Pin },
  { label: 'Mark all read', icon: Mail },
  { label: 'Undo', icon: Undo2 },
]

export function MailApp() {
  const [selected, setSelected] = useState(emails[0].id)
  const [mobileReading, setMobileReading] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const current = emails.find((e) => e.id === selected) ?? emails[0]

  return (
    <div className="flex h-dvh bg-muted/40">
      <aside className="hidden w-64 shrink-0 lg:block">
        <FolderSidebar />
      </aside>

      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Mail folders">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-ink/50" onClick={() => setMenuOpen(false)} />
          <div className="relative h-full w-72">
            <FolderSidebar onClose={() => setMenuOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center gap-3 border-b border-border bg-background px-4 sm:px-6">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="flex size-10 items-center justify-center rounded-full hover:bg-muted lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </button>
          <label className="relative max-w-xl flex-1">
            <span className="sr-only">Search mail</span>
            <Search className="absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              type="search"
              placeholder="Search mail and people"
              className="h-10 w-full rounded-full bg-muted pl-11 pr-4 text-sm outline-none transition placeholder:text-muted-foreground focus:bg-background focus:ring-2 focus:ring-ink/10"
            />
          </label>
          <div className="ml-auto flex items-center gap-1">
            <Link href="/dashboard" aria-label="Apps" className="hidden size-10 items-center justify-center rounded-full hover:bg-muted sm:flex">
              <LayoutGrid className="size-5" />
            </Link>
            <button type="button" aria-label="Notifications" className="relative flex size-10 items-center justify-center rounded-full hover:bg-muted">
              <Bell className="size-5" />
              <span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-primary ring-2 ring-background" />
            </button>
          </div>
        </header>

        <div className="hidden shrink-0 items-center gap-1 overflow-x-auto border-b border-border bg-background px-4 py-2 sm:flex sm:px-6">
          {ribbon.map((r) => (
            <button
              key={r.label}
              type="button"
              className="flex h-9 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium transition hover:bg-muted"
            >
              <r.icon className="size-4" aria-hidden="true" /> {r.label}
            </button>
          ))}
          <button
            type="button"
            aria-label="Check for new messages"
            className="ml-auto flex size-9 shrink-0 items-center justify-center rounded-full hover:bg-muted"
          >
            <RefreshCw className="size-4" />
          </button>
        </div>

        <div className="flex min-h-0 flex-1">
          <section
            aria-label="Message list"
            className={cn(
              'flex w-full shrink-0 flex-col border-r border-border bg-background md:w-[380px]',
              mobileReading && 'hidden md:flex',
            )}
          >
            <div className="flex items-center justify-between px-5 py-4">
              <div>
                <h1 className="text-xl font-bold tracking-tight">Inbox</h1>
                <p className="text-xs text-muted-foreground">12 unread · All folders up to date</p>
              </div>
              <div className="flex rounded-full bg-muted p-1 text-xs font-semibold">
                <span className="rounded-full bg-background px-3 py-1 shadow-sm">Focused</span>
                <span className="px-3 py-1 text-muted-foreground">Other</span>
              </div>
            </div>
            <ul className="flex-1 overflow-y-auto">
              {emails.map((e) => (
                <li key={e.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setSelected(e.id)
                      setMobileReading(true)
                    }}
                    aria-current={e.id === selected ? 'true' : undefined}
                    className={cn(
                      'relative flex w-full gap-3 border-b border-border px-5 py-4 text-left transition',
                      e.id === selected ? 'bg-muted' : 'hover:bg-muted/60',
                    )}
                  >
                    {e.id === selected && <span className="absolute inset-y-0 left-0 w-1 bg-primary" aria-hidden="true" />}
                    <span
                      className={cn(
                        'flex size-10 shrink-0 items-center justify-center rounded-full text-xs font-bold',
                        e.unread ? 'bg-ink text-ink-foreground' : 'bg-secondary',
                      )}
                    >
                      {initials(e.from)}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center justify-between gap-2">
                        <span className={cn('truncate text-sm', e.unread ? 'font-bold' : 'font-medium')}>{e.from}</span>
                        <span className={cn('shrink-0 text-xs', e.unread ? 'font-bold' : 'text-muted-foreground')}>
                          {e.time}
                        </span>
                      </span>
                      <span className={cn('mt-0.5 block truncate text-sm', e.unread && 'font-semibold')}>{e.subject}</span>
                      <span className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{e.preview}</span>
                      <span className="mt-2 flex items-center gap-2">
                        {e.category && (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-background px-2 py-0.5 text-[10px] font-semibold ring-1 ring-border">
                            <span className={cn('size-1.5 rounded-full', categoryColor[e.category])} />
                            {e.category}
                          </span>
                        )}
                        {e.attachment && <Paperclip className="size-3.5 text-muted-foreground" aria-label="Has attachment" />}
                        {e.starred && <Star className="size-3.5 fill-primary text-primary" aria-label="Starred" />}
                        {e.unread && <span className="ml-auto size-2 rounded-full bg-primary" aria-label="Unread" />}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>

          <article
            aria-label="Reading pane"
            className={cn('min-w-0 flex-1 flex-col overflow-y-auto bg-muted/40 p-4 sm:p-6', mobileReading ? 'flex' : 'hidden md:flex')}
          >
            <button
              type="button"
              onClick={() => setMobileReading(false)}
              className="mb-4 flex w-fit items-center gap-2 rounded-full bg-background px-4 py-2 text-sm font-semibold ring-1 ring-border md:hidden"
            >
              <ArrowLeft className="size-4" aria-hidden="true" /> Back to inbox
            </button>

            <div className="rounded-3xl bg-background p-6 ring-1 ring-border sm:p-8">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <h2 className="text-balance text-2xl font-bold tracking-tight">{current.subject}</h2>
                <div className="flex items-center gap-1">
                  {[
                    { icon: Pin, label: 'Pin to top of folder' },
                    { icon: Printer, label: 'Print message' },
                    { icon: Trash2, label: 'Delete message' },
                    { icon: MoreHorizontal, label: 'More options' },
                  ].map((a) => (
                    <button
                      key={a.label}
                      type="button"
                      aria-label={a.label}
                      className="flex size-9 items-center justify-center rounded-full hover:bg-muted"
                    >
                      <a.icon className="size-4" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex items-center gap-3 border-b border-border pb-6">
                <span className="flex size-11 items-center justify-center rounded-full bg-ink text-sm font-bold text-ink-foreground">
                  {initials(current.from)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{current.from}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {current.email} · to rahim@tiwlo.com
                  </p>
                </div>
                <span className="text-xs text-muted-foreground">{current.time}</span>
              </div>

              <div className="prose-sm mt-6 flex flex-col gap-4 text-sm leading-relaxed text-foreground/85">
                <p>Hi Rahim,</p>
                <p>{current.preview}</p>
                <p>
                  You can review the full details from your Tiwlo console at any time. If anything looks off, reply to
                  this email and our team will get back to you within one business day.
                </p>
                <p>
                  Best regards,
                  <br />
                  {current.from}
                </p>
              </div>

              {current.attachment && (
                <div className="mt-6 flex w-fit items-center gap-3 rounded-2xl bg-muted p-3 pr-5">
                  <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                    <FileText className="size-4" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold">INV-2026-011.pdf</p>
                    <p className="text-xs text-muted-foreground">148 KB</p>
                  </div>
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-2">
                <button type="button" className="inline-flex h-10 items-center gap-2 rounded-full bg-ink px-5 text-sm font-bold text-ink-foreground">
                  <Reply className="size-4" aria-hidden="true" /> Reply
                </button>
                <button type="button" className="inline-flex h-10 items-center gap-2 rounded-full bg-background px-5 text-sm font-bold ring-1 ring-border hover:bg-muted">
                  <ReplyAll className="size-4" aria-hidden="true" /> Reply all
                </button>
                <button type="button" className="inline-flex h-10 items-center gap-2 rounded-full bg-background px-5 text-sm font-bold ring-1 ring-border hover:bg-muted">
                  <Send className="size-4" aria-hidden="true" /> Forward
                </button>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  )
}
