import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string
  title: string
  description?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{eyebrow}</p>}
        <h1 className="mt-1 text-balance text-3xl font-bold tracking-tight sm:text-4xl">{title}</h1>
        {description && <p className="mt-2 max-w-2xl text-pretty text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function Panel({
  title,
  action,
  className,
  children,
  id,
}: {
  title?: string
  action?: React.ReactNode
  className?: string
  children: React.ReactNode
  id?: string
}) {
  return (
    <section id={id} className={cn('rounded-3xl bg-background p-5 ring-1 ring-border sm:p-6', className)}>
      {title && (
        <div className="mb-5 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold tracking-tight">{title}</h2>
          {action}
        </div>
      )}
      {children}
    </section>
  )
}

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  tone = 'default',
}: {
  label: string
  value: string
  hint?: string
  icon: LucideIcon
  tone?: 'default' | 'ink' | 'primary'
}) {
  return (
    <div
      className={cn(
        'flex flex-col justify-between gap-6 rounded-3xl p-5 ring-1',
        tone === 'ink' && 'bg-ink text-ink-foreground ring-ink',
        tone === 'primary' && 'bg-primary text-primary-foreground ring-primary',
        tone === 'default' && 'bg-background ring-border',
      )}
    >
      <div className="flex items-center justify-between">
        <span className={cn('text-sm font-medium', tone === 'default' ? 'text-muted-foreground' : 'opacity-70')}>
          {label}
        </span>
        <span
          className={cn(
            'flex size-9 items-center justify-center rounded-full',
            tone === 'default' && 'bg-muted',
            tone === 'ink' && 'bg-white/10',
            tone === 'primary' && 'bg-ink/10',
          )}
        >
          <Icon className="size-4" aria-hidden="true" />
        </span>
      </div>
      <div>
        <p className="text-3xl font-bold tracking-tight">{value}</p>
        {hint && (
          <p className={cn('mt-1 text-xs', tone === 'default' ? 'text-muted-foreground' : 'opacity-60')}>{hint}</p>
        )}
      </div>
    </div>
  )
}

export function StatusPill({ status }: { status: string }) {
  const s = status.toLowerCase()
  const tone =
    s === 'active' || s === 'running' || s === 'in stock' || s === 'live' || s === 'operational' || s === 'paid'
      ? 'bg-primary/15 text-[#0f7a37]'
      : s === 'low stock' || s === 'pending' || s === 'degraded'
        ? 'bg-amber-100 text-amber-800'
        : s === 'out of stock' || s === 'stopped' || s === 'off'
          ? 'bg-red-100 text-red-700'
          : 'bg-muted text-muted-foreground'
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold', tone)}>
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {status}
    </span>
  )
}

export function PillButton({
  children,
  variant = 'ink',
  className,
}: {
  children: React.ReactNode
  variant?: 'ink' | 'primary' | 'outline'
  className?: string
}) {
  return (
    <button
      type="button"
      className={cn(
        'inline-flex h-10 items-center gap-2 rounded-full px-5 text-sm font-bold transition',
        variant === 'ink' && 'bg-ink text-ink-foreground hover:bg-ink/85',
        variant === 'primary' && 'bg-primary text-primary-foreground hover:bg-primary/85',
        variant === 'outline' && 'bg-background ring-1 ring-border hover:bg-muted',
        className,
      )}
    >
      {children}
    </button>
  )
}
