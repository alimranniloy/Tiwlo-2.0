'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { Bell, ChevronsUpDown, Menu, Plus, Search, Sparkles, X } from 'lucide-react'
import { Logo } from '@/components/brand/logo'
import { cn } from '@/lib/utils'
import { shellConfig, type ShellVariant } from './nav-config'

const workspaces: Record<ShellVariant, { name: string; meta: string; initials: string }> = {
  cloud: { name: 'Tiwlo Workspace', meta: 'Cloud · Growth plan', initials: 'TW' },
  ecommerce: { name: 'TiwiMart', meta: 'Online store · Pro', initials: 'TM' },
  oneprofile: { name: 'Rahim.uids.app', meta: 'Free Plan', initials: 'RU' },
}

function SidebarContent({ variant, onNavigate }: { variant: ShellVariant; onNavigate?: () => void }) {
  const pathname = usePathname()
  const config = shellConfig[variant]
  const ws = workspaces[variant]

  return (
    <div className="flex h-full flex-col gap-6 bg-ink p-4 text-ink-foreground">
      <div className="flex items-center justify-between px-2 pt-2">
        <Logo inverted href={config.root} suffix={config.product} />
        {onNavigate && (
          <button
            type="button"
            onClick={onNavigate}
            aria-label="Close menu"
            className="flex size-8 items-center justify-center rounded-full text-white/70 hover:bg-white/10"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      <button
        type="button"
        className="flex w-full items-center gap-3 rounded-xl bg-white/5 p-2.5 text-left ring-1 ring-white/10 transition hover:bg-white/10"
      >
        <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
          {ws.initials}
        </span>
        <span className="flex min-w-0 flex-1 flex-col">
          <span className="truncate text-sm font-semibold text-white">{ws.name}</span>
          <span className="text-xs text-white/50">{ws.meta}</span>
        </span>
        <ChevronsUpDown className="size-4 text-white/50" aria-hidden="true" />
      </button>

      <nav aria-label="Main" className="-mx-1 flex flex-1 flex-col gap-6 overflow-y-auto px-1">
        {config.groups.map((group) => (
          <div key={group.label}>
            <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-widest text-white/40">{group.label}</p>
            <ul className="flex flex-col gap-0.5">
              {group.items.map((item) => {
                const active = item.href === pathname
                return (
                  <li key={item.href + item.label}>
                    <Link
                      href={item.href}
                      onClick={onNavigate}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition',
                        active ? 'bg-white text-ink' : 'text-white/65 hover:bg-white/5 hover:text-white',
                      )}
                    >
                      <item.icon className="size-[18px] shrink-0" aria-hidden="true" />
                      <span className="flex-1 truncate">{item.label}</span>
                      {item.badge && (
                        <span
                          className={cn(
                            'rounded-full px-2 py-0.5 text-[10px] font-bold',
                            active ? 'bg-ink text-ink-foreground' : 'bg-primary text-primary-foreground',
                          )}
                        >
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="rounded-2xl bg-primary p-4 text-primary-foreground">
        <div className="flex items-center gap-2 text-sm font-bold">
          <Sparkles className="size-4" aria-hidden="true" /> {config.promo.title}
        </div>
        <p className="mt-1 text-xs leading-relaxed text-primary-foreground/70">{config.promo.body}</p>
        <button
          type="button"
          className="mt-3 inline-flex h-8 items-center rounded-full bg-ink px-4 text-xs font-bold text-ink-foreground transition hover:bg-ink/85"
        >
          {config.promo.cta}
        </button>
      </div>
    </div>
  )
}

function Topbar({ variant, onMenu }: { variant: ShellVariant; onMenu: () => void }) {
  const config = shellConfig[variant]
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/85 px-4 backdrop-blur-md sm:px-6">
      <button
        type="button"
        onClick={onMenu}
        className="flex size-10 items-center justify-center rounded-full hover:bg-muted lg:hidden"
        aria-label="Open menu"
      >
        <Menu className="size-5" />
      </button>

      <label className="relative hidden max-w-md flex-1 md:block">
        <span className="sr-only">Search</span>
        <Search className="absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <input
          type="search"
          placeholder={config.search}
          className="h-10 w-full rounded-full bg-muted pl-11 pr-4 text-sm outline-none ring-ink/10 transition placeholder:text-muted-foreground focus:bg-background focus:ring-2"
        />
      </label>

      <div className="ml-auto flex items-center gap-2">
        <button
          type="button"
          className="flex h-10 items-center gap-1.5 rounded-full bg-ink px-4 text-sm font-bold text-ink-foreground transition hover:bg-ink/85"
        >
          <Plus className="size-4" aria-hidden="true" /> <span className="hidden sm:inline">Create</span>
        </button>
        <button
          type="button"
          className="relative flex size-10 items-center justify-center rounded-full hover:bg-muted"
          aria-label="Notifications"
        >
          <Bell className="size-5" />
          <span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-primary ring-2 ring-background" />
        </button>
        <Link
          href="/oneprofile"
          aria-label="Account"
          className="flex size-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground"
        >
          RH
        </Link>
      </div>
    </header>
  )
}

export function DashboardShell({ variant, children }: { variant: ShellVariant; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="flex min-h-dvh bg-muted/40">
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 lg:block">
        <SidebarContent variant={variant} />
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
          <button
            type="button"
            aria-label="Close menu"
            className="absolute inset-0 bg-ink/50"
            onClick={() => setOpen(false)}
          />
          <div className="relative h-full w-72 animate-in slide-in-from-left duration-200">
            <SidebarContent variant={variant} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar variant={variant} onMenu={() => setOpen(true)} />
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-10">{children}</main>
      </div>
    </div>
  )
}
