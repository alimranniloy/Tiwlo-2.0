import {
  Archive,
  BadgePercent,
  BarChart3,
  Boxes,
  Camera,
  Cloud,
  Container,
  CreditCard,
  Fingerprint,
  FolderTree,
  Globe,
  HardDrive,
  HelpCircle,
  Image as ImageIcon,
  LayoutGrid,
  LayoutTemplate,
  LifeBuoy,
  Mail,
  Megaphone,
  MonitorSmartphone,
  Nfc,
  Package,
  PanelsTopLeft,
  Plus,
  Receipt,
  Server,
  Settings2,
  ShoppingBag,
  ShoppingCart,
  Star,
  Store,
  Truck,
  UserCog,
  UserRound,
  Users,
  Wallet,
  type LucideIcon,
} from 'lucide-react'

export type NavItem = { href: string; label: string; icon: LucideIcon; badge?: string }
export type NavGroup = { label: string; items: NavItem[] }
export type ShellVariant = 'cloud' | 'ecommerce' | 'oneprofile'

export const shellConfig: Record<
  ShellVariant,
  {
    product: string
    root: string
    search: string
    groups: NavGroup[]
    promo: { title: string; body: string; cta: string }
  }
> = {
  cloud: {
    product: 'Cloud',
    root: '/dashboard',
    search: 'Search droplets, domains, images…',
    groups: [
      {
        label: 'Infrastructure',
        items: [
          { href: '/dashboard', label: 'Dashboard', icon: LayoutGrid },
          { href: '/dashboard#droplets', label: 'My Droplets', icon: Server },
          { href: '/dashboard#create', label: 'Create Droplet', icon: Plus },
          { href: '/dashboard#kubernetes', label: 'Kubernetes', icon: Container },
          { href: '/dashboard#volumes', label: 'Volumes', icon: HardDrive },
          { href: '/dashboard#images', label: 'Images', icon: ImageIcon },
          { href: '/dashboard#snapshots', label: 'Snapshots', icon: Camera },
          { href: '/dashboard#backups', label: 'Backups', icon: Archive },
          { href: '/dashboard#domains', label: 'Domains', icon: Globe },
          { href: '/dashboard#tpanel', label: 'TPanel Control Panel', icon: PanelsTopLeft },
        ],
      },
      {
        label: 'Workspace hub',
        items: [
          { href: '/ecommerce', label: 'Online store', icon: Store },
          { href: '/email', label: 'Email (Tiwi Mail)', icon: Mail, badge: '12' },
          { href: '/oneprofile', label: 'OneProfile', icon: UserRound },
          { href: '/dashboard#marketplace', label: 'Marketplace', icon: ShoppingBag },
          { href: '/dashboard#identity', label: 'Identity', icon: Fingerprint },
        ],
      },
      {
        label: 'Account',
        items: [
          { href: '/dashboard#billing', label: 'Billing', icon: CreditCard },
          { href: '/dashboard#settings', label: 'Settings', icon: Settings2 },
          { href: '/dashboard#help', label: 'Help & support', icon: HelpCircle },
        ],
      },
    ],
    promo: {
      title: 'Create a store',
      body: 'Launch a mobile-optimized storefront with POS in under 5 minutes.',
      cta: 'Open store',
    },
  },
  ecommerce: {
    product: 'Store',
    root: '/ecommerce',
    search: 'Search products, orders, customers…',
    groups: [
      {
        label: 'Main Control Center',
        items: [
          { href: '/ecommerce', label: 'Store Dashboard', icon: LayoutGrid },
          { href: '/ecommerce#pos', label: 'POS System', icon: MonitorSmartphone },
          { href: '/ecommerce#products', label: 'Products', icon: Package },
          { href: '/ecommerce#categories', label: 'Categories & Subs', icon: FolderTree },
          { href: '/ecommerce#inventory', label: 'Inventory Control', icon: Boxes },
          { href: '/ecommerce#sales', label: 'Sales & Orders', icon: ShoppingCart, badge: '8' },
          { href: '/ecommerce#purchases', label: 'Purchases (PO)', icon: Receipt },
          { href: '/ecommerce#suppliers', label: 'Suppliers', icon: Truck },
          { href: '/ecommerce#customers', label: 'Customers', icon: Users },
        ],
      },
      {
        label: 'Insights',
        items: [
          { href: '/ecommerce#analytics', label: 'Analytics', icon: BarChart3 },
          { href: '/ecommerce#marketing', label: 'Marketing', icon: Megaphone },
          { href: '/ecommerce#promo', label: 'Promo Codes', icon: BadgePercent },
          { href: '/ecommerce#reviews', label: 'Product Reviews', icon: Star },
        ],
      },
      {
        label: 'Store management',
        items: [
          { href: '/ecommerce#storefront', label: 'Storefront & Theme', icon: LayoutTemplate },
          { href: '/ecommerce#payments', label: 'Payments', icon: Wallet },
          { href: '/ecommerce#shipping', label: 'Shipping', icon: Truck },
          { href: '/ecommerce#staff', label: 'Staff Management', icon: UserCog },
          { href: '/email', label: 'Tiwi Mail', icon: Mail },
          { href: '/dashboard', label: 'Workspace', icon: Cloud },
        ],
      },
    ],
    promo: {
      title: 'Upgrade & Plans',
      body: 'Unlock custom domains, multi-branch POS and staff roles.',
      cta: 'Upgrade now',
    },
  },
  oneprofile: {
    product: 'UIDs',
    root: '/oneprofile',
    search: 'Search websites, subdomains, templates…',
    groups: [
      {
        label: 'OneProfile',
        items: [
          { href: '/oneprofile', label: 'My Website', icon: Globe },
          { href: '/oneprofile#subdomains', label: 'Subdomains', icon: Fingerprint },
          { href: '/oneprofile#templates', label: 'Templates', icon: LayoutTemplate },
          { href: '/oneprofile#hosting', label: 'Cloud Hosting', icon: Cloud },
          { href: '/oneprofile#nfc', label: 'NFC Card', icon: Nfc },
          { href: '/oneprofile#analytics', label: 'Analytics', icon: BarChart3 },
        ],
      },
      {
        label: 'Account',
        items: [
          { href: '/oneprofile#billing', label: 'Billing', icon: CreditCard },
          { href: '/oneprofile#settings', label: 'Settings', icon: Settings2 },
          { href: '/oneprofile#support', label: 'Support', icon: LifeBuoy },
          { href: '/dashboard', label: 'Back to Console', icon: LayoutGrid },
        ],
      },
    ],
    promo: {
      title: 'Upgrade to Pro',
      body: 'Custom domain, Node.js support, more storage and premium templates.',
      cta: 'Upgrade now',
    },
  },
}
