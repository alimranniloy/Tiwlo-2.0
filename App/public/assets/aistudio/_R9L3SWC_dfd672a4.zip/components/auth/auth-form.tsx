import Link from 'next/link'

function Field({
  id,
  label,
  type = 'text',
  placeholder,
  autoComplete,
  aside,
}: {
  id: string
  label: string
  type?: string
  placeholder: string
  autoComplete?: string
  aside?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <label htmlFor={id} className="text-sm font-semibold">
          {label}
        </label>
        {aside}
      </div>
      <input
        id={id}
        name={id}
        type={type}
        placeholder={placeholder}
        autoComplete={autoComplete}
        className="h-12 rounded-xl bg-muted px-4 text-sm outline-none ring-ink/10 transition placeholder:text-muted-foreground focus:bg-background focus:ring-2"
      />
    </div>
  )
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
      <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.66-5.17 3.66-9.12z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.27 21.41 7.34 24 12 24z" />
      <path fill="#FBBC05" d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.57H1.25C.45 8.16 0 9.98 0 12s.45 3.84 1.25 5.43l4.03-3.14z" />
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.27 2.59 1.25 6.57l4.03 3.14c.95-2.83 3.6-4.96 6.72-4.96z" />
    </svg>
  )
}

function GitHubIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" fill="currentColor" aria-hidden="true">
      <path d="M12 .9a11.1 11.1 0 0 0-3.51 21.63c.56.1.76-.24.76-.54v-2.1c-3.1.67-3.76-1.32-3.76-1.32-.51-1.29-1.24-1.63-1.24-1.63-1.02-.7.08-.69.08-.69 1.13.08 1.73 1.16 1.73 1.16 1 .1.76 2.01 3.44 1.54.1-.73.4-1.22.69-1.5-2.48-.28-5.09-1.24-5.09-5.53 0-1.22.44-2.22 1.16-3-.12-.28-.5-1.42.11-2.96 0 0 .95-.3 3.05 1.15a10.6 10.6 0 0 1 5.55 0c2.1-1.45 3.05-1.15 3.05-1.15.61 1.54.23 2.68.11 2.96.72.78 1.16 1.78 1.16 3 0 4.3-2.62 5.25-5.12 5.52.4.35.75 1.03.75 2.08v3.08c0 .3.2.65.77.54A11.1 11.1 0 0 0 12 .9Z" />
    </svg>
  )
}

export function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const isLogin = mode === 'login'
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-balance text-3xl font-bold tracking-tight">
          {isLogin ? 'Sign in to Tiwlo' : 'Create your Tiwlo Account'}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {isLogin
            ? 'Use your email or Tiwi ID to continue to your console.'
            : 'One account for Cloud, Store, Tiwlo Mail and OneProfile.'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          className="flex h-12 items-center justify-center gap-2 rounded-full text-sm font-semibold ring-1 ring-border transition hover:bg-muted"
        >
          <GoogleIcon /> Google
        </button>
        <button
          type="button"
          className="flex h-12 items-center justify-center gap-2 rounded-full text-sm font-semibold ring-1 ring-border transition hover:bg-muted"
        >
          <GitHubIcon /> GitHub
        </button>
      </div>

      <div className="flex items-center gap-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
      </div>

      <form className="flex flex-col gap-5" action="#">
        {!isLogin && <Field id="name" label="Full name" placeholder="First and last name" autoComplete="name" />}
        <Field
          id="email"
          label={isLogin ? 'Email or Tiwi ID' : 'Email'}
          placeholder={isLogin ? 'Email or Tiwi ID' : 'you@company.com'}
          autoComplete="email"
        />
        <Field
          id="password"
          label="Password"
          type="password"
          placeholder={isLogin ? 'Enter your password' : 'Min 6 characters'}
          autoComplete={isLogin ? 'current-password' : 'new-password'}
          aside={
            isLogin ? (
              <Link href="#" className="text-xs font-semibold text-muted-foreground hover:text-foreground">
                Forgot password?
              </Link>
            ) : undefined
          }
        />
        {!isLogin && (
          <label className="flex items-start gap-3 text-sm text-muted-foreground">
            <input type="checkbox" className="mt-0.5 size-4 accent-[#1ed760]" />
            <span>I agree to the Terms of Service and Security & Privacy Policy.</span>
          </label>
        )}
        <button
          type="button"
          className="mt-2 h-12 rounded-full bg-primary text-sm font-bold text-primary-foreground transition hover:bg-primary/85"
        >
          {isLogin ? 'Continue' : 'Create account'}
        </button>
      </form>

      <p className="text-center text-sm text-muted-foreground">
        {isLogin ? 'New to Tiwlo? ' : 'Already have an account? '}
        <Link href={isLogin ? '/signup' : '/login'} className="font-bold text-foreground underline-offset-4 hover:underline">
          {isLogin ? 'Create account' : 'Sign in'}
        </Link>
      </p>
    </div>
  )
}
