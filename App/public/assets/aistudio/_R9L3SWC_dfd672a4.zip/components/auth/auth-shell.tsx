import { Check } from 'lucide-react'
import { Logo } from '@/components/brand/logo'

const highlights = [
  'Enterprise 99.99% SLA guarantee',
  'Online stores with omnichannel POS',
  'Tiwlo Mail, OneProfile and Cloud in one account',
]

export function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <main className="grid min-h-dvh lg:grid-cols-2">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-ink p-12 text-ink-foreground lg:flex">
        <Logo inverted />
        <div className="relative z-10 max-w-md">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">One Tiwlo Account</p>
          <h2 className="mt-4 text-balance text-5xl font-bold leading-[1.05] tracking-tight">
            Accelerate your business with Tiwlo Cloud.
          </h2>
          <ul className="mt-10 flex flex-col gap-4">
            {highlights.map((item) => (
              <li key={item} className="flex items-center gap-3 text-base text-white/80">
                <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Check className="size-3.5" strokeWidth={3} aria-hidden="true" />
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="relative z-10 flex items-center gap-4 rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-full bg-white text-sm font-bold text-ink">AR</div>
          <div>
            <p className="text-sm leading-relaxed text-white/80">
              {'“We moved our storefront, POS and API to Tiwlo in a weekend. One console for everything.”'}
            </p>
            <p className="mt-1 text-xs font-semibold text-white/50">Ayesha Rahman, Founder at Northwind</p>
          </div>
        </div>
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-56 -right-56 size-[520px] rounded-full border-[56px] border-primary/90"
        />
      </section>

      <section className="flex flex-col px-6 py-10 sm:px-12">
        <div className="lg:hidden">
          <Logo />
        </div>
        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10">{children}</div>
        <p className="text-center text-xs text-muted-foreground">
          {'Protected by Tiwlo security · Terms of Service · Privacy Policy'}
        </p>
      </section>
    </main>
  )
}
