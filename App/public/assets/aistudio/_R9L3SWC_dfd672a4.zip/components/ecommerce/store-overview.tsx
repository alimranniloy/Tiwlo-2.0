import {
  AlertTriangle,
  Barcode,
  Boxes,
  Check,
  DollarSign,
  ExternalLink,
  FileBarChart,
  FileUp,
  LayoutGrid,
  List,
  MoreHorizontal,
  Package,
  Plus,
  Printer,
  Search,
  ShoppingCart,
  Truck,
} from 'lucide-react'
import { TrendArea, TrendBars } from '@/components/shell/charts'
import { PageHeader, Panel, PillButton, StatCard, StatusPill } from '@/components/shell/primitives'
import { cn } from '@/lib/utils'

const quickActions = [
  { label: 'Add Product', icon: Plus },
  { label: 'New Purchase', icon: Truck },
  { label: 'New Sale', icon: ShoppingCart },
  { label: 'Scan Barcode', icon: Barcode },
  { label: 'Import CSV', icon: FileUp },
  { label: 'Generate Report', icon: FileBarChart },
]

const checklist = [
  { title: 'Store details', body: 'Add a store name and a way for customers to contact you.', done: true },
  { title: 'Add a product', body: 'Add a product with a photo, price, and available stock.', done: true },
  { title: 'Organize your catalog', body: 'Create at least one category so shoppers can browse your products.', done: true },
  { title: 'Set your homepage banner', body: 'Add an active banner to introduce your store.', done: false },
  { title: 'Set up payments', body: 'Enable at least one payment provider with saved credentials.', done: false },
  { title: 'Configure shipping', body: 'Set a shipping zone or a flat shipping rate.', done: false },
  { title: 'Add store policies', body: 'Publish useful pages such as returns, privacy, and terms.', done: false },
  { title: 'Add your store logo', body: 'Make your brand recognizable across the storefront.', done: true },
]

const stockMovement = [
  { label: 'Jan', in: 420, out: 310 },
  { label: 'Feb', in: 380, out: 290 },
  { label: 'Mar', in: 510, out: 420 },
  { label: 'Apr', in: 460, out: 400 },
  { label: 'May', in: 590, out: 520 },
  { label: 'Jun', in: 640, out: 560 },
]

const salesTrend = [
  { label: 'W1', sales: 3200 },
  { label: 'W2', sales: 4100 },
  { label: 'W3', sales: 3800 },
  { label: 'W4', sales: 5200 },
  { label: 'W5', sales: 4900 },
  { label: 'W6', sales: 6100 },
]

const products = [
  { name: 'Classic Cotton Tee', sku: 'TM-CLO-001', category: 'Clothing', stock: 124, price: '$18.00' },
  { name: 'Runner Pro Sneakers', sku: 'TM-FTW-014', category: 'Footwear', stock: 8, price: '$89.00' },
  { name: 'Wireless Earbuds X2', sku: 'TM-ELC-203', category: 'Electronics', stock: 0, price: '$59.00' },
  { name: 'Leather Card Wallet', sku: 'TM-ACC-042', category: 'Accessories', stock: 56, price: '$24.00' },
  { name: 'Vitamin C Serum', sku: 'TM-BTY-117', category: 'Beauty & Health', stock: 5, price: '$32.00' },
  { name: 'Linen Cushion Cover', sku: 'TM-HOM-088', category: 'Home & Living', stock: 73, price: '$15.00' },
]

const topSelling = [
  { name: 'Classic Cotton Tee', sold: 412, revenue: '$7,416' },
  { name: 'Runner Pro Sneakers', sold: 188, revenue: '$16,732' },
  { name: 'Leather Card Wallet', sold: 164, revenue: '$3,936' },
  { name: 'Vitamin C Serum', sold: 139, revenue: '$4,448' },
]

const activity = [
  { text: 'Sale #1048 completed via POS', time: '5 min ago' },
  { text: 'Purchase order PO-221 received from Dhaka Textiles', time: '1 hour ago' },
  { text: 'Wireless Earbuds X2 is out of stock', time: '3 hours ago' },
  { text: 'New customer Nusrat Jahan registered', time: 'Yesterday' },
]

const categories = ['All Categories', 'Clothing', 'Footwear', 'Electronics', 'Accessories', 'Beauty & Health', 'Home & Living']

function stockStatus(stock: number) {
  if (stock === 0) return 'Out of Stock'
  if (stock < 10) return 'Low Stock'
  return 'In Stock'
}

export function StoreOverview() {
  const doneCount = checklist.filter((c) => c.done).length
  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        eyebrow="Mon, Sep 22, 2025"
        title="Good morning, Admin"
        description="Here is what is happening across TiwiMart today — inventory, sales and your store setup."
        actions={
          <>
            <PillButton variant="outline">
              <ExternalLink className="size-4" aria-hidden="true" /> Visit Site
            </PillButton>
            <PillButton>
              <Plus className="size-4" aria-hidden="true" /> Add Product
            </PillButton>
          </>
        }
      />

      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {quickActions.map((a, i) => (
          <button
            key={a.label}
            type="button"
            className={cn(
              'flex flex-col items-center gap-2.5 rounded-2xl p-4 text-center text-xs font-bold ring-1 transition',
              i === 0
                ? 'bg-primary text-primary-foreground ring-primary hover:bg-primary/85'
                : 'bg-background ring-border hover:bg-muted',
            )}
          >
            <span
              className={cn(
                'flex size-10 items-center justify-center rounded-full',
                i === 0 ? 'bg-ink text-ink-foreground' : 'bg-muted',
              )}
            >
              <a.icon className="size-4" aria-hidden="true" />
            </span>
            {a.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Products" value="1,284" hint="Current total" icon={Package} tone="ink" />
        <StatCard label="Total Stock (Units)" value="18,920" hint="Across 3 warehouses" icon={Boxes} />
        <StatCard label="Total Sales" value="$42,580" hint="+12.4% vs last month" icon={DollarSign} tone="primary" />
        <StatCard label="Low Stock Items" value="23" hint="Needs reorder" icon={AlertTriangle} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel title="Finish setting up your store" className="lg:col-span-1">
          <div className="mb-5">
            <div className="flex items-baseline justify-between text-sm">
              <span className="font-semibold">
                {doneCount} of {checklist.length} complete
              </span>
              <span className="text-muted-foreground">{Math.round((doneCount / checklist.length) * 100)}%</span>
            </div>
            <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${(doneCount / checklist.length) * 100}%` }}
              />
            </div>
          </div>
          <ul className="flex flex-col gap-1">
            {checklist.map((c) => (
              <li key={c.title} className="flex items-start gap-3 rounded-xl p-2 transition hover:bg-muted">
                <span
                  className={cn(
                    'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full',
                    c.done ? 'bg-primary text-primary-foreground' : 'ring-2 ring-border',
                  )}
                >
                  {c.done && <Check className="size-3" strokeWidth={3} aria-hidden="true" />}
                </span>
                <div className="min-w-0 flex-1">
                  <p className={cn('text-sm font-semibold', c.done && 'text-muted-foreground line-through')}>{c.title}</p>
                  {!c.done && <p className="text-xs text-muted-foreground">{c.body}</p>}
                </div>
                <span className="text-xs font-bold">{c.done ? 'Review' : 'Set up'}</span>
              </li>
            ))}
          </ul>
        </Panel>

        <div className="flex flex-col gap-6 lg:col-span-2">
          <Panel
            title="Stock Movement"
            action={
              <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="size-2 rounded-full bg-[#1ed760]" /> Stock in
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="size-2 rounded-full bg-[#121212]" /> Stock out
                </span>
              </div>
            }
          >
            <TrendBars
              data={stockMovement}
              height={220}
              keys={[
                { key: 'in', color: '#1ed760', label: 'Stock in' },
                { key: 'out', color: '#121212', label: 'Stock out' },
              ]}
            />
          </Panel>
          <Panel
            title="Inventory Overview"
            action={
              <span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold">All Categories</span>
            }
          >
            <TrendArea data={salesTrend} height={200} keys={[{ key: 'sales', color: '#1ed760', label: 'Sales $' }]} />
          </Panel>
        </div>
      </div>

      <Panel id="products" title="Recent Products">
        <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {categories.map((c, i) => (
              <span
                key={c}
                className={cn(
                  'shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold',
                  i === 0 ? 'bg-ink text-ink-foreground' : 'bg-muted text-foreground',
                )}
              >
                {c}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <label className="relative flex-1 lg:w-64 lg:flex-none">
              <span className="sr-only">Search products</span>
              <Search className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <input
                type="search"
                placeholder="Search products..."
                className="h-9 w-full rounded-full bg-muted pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-ink/10"
              />
            </label>
            <div className="flex rounded-full bg-muted p-1">
              <button type="button" aria-label="List view" className="flex size-7 items-center justify-center rounded-full bg-background">
                <List className="size-4" />
              </button>
              <button type="button" aria-label="Grid view" className="flex size-7 items-center justify-center rounded-full">
                <LayoutGrid className="size-4" />
              </button>
            </div>
          </div>
        </div>
        <div className="-mx-5 overflow-x-auto sm:-mx-6">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                <th className="px-5 pb-3 font-semibold sm:px-6">Product Name</th>
                <th className="pb-3 font-semibold">SKU</th>
                <th className="pb-3 font-semibold">Category</th>
                <th className="pb-3 font-semibold">Stock</th>
                <th className="pb-3 font-semibold">Price</th>
                <th className="pb-3 font-semibold">Status</th>
                <th className="px-5 pb-3 text-right font-semibold sm:px-6">Action</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.sku} className="border-b border-border last:border-0">
                  <td className="px-5 py-3.5 sm:px-6">
                    <div className="flex items-center gap-3">
                      <span className="flex size-10 items-center justify-center rounded-xl bg-muted text-xs font-bold">
                        {p.name
                          .split(' ')
                          .map((w) => w[0])
                          .slice(0, 2)
                          .join('')}
                      </span>
                      <span className="font-semibold">{p.name}</span>
                    </div>
                  </td>
                  <td className="font-mono text-xs text-muted-foreground">{p.sku}</td>
                  <td>{p.category}</td>
                  <td className="font-semibold">{p.stock}</td>
                  <td className="font-semibold">{p.price}</td>
                  <td>
                    <StatusPill status={stockStatus(p.stock)} />
                  </td>
                  <td className="px-5 sm:px-6">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        type="button"
                        aria-label="Print Barcode"
                        className="flex size-8 items-center justify-center rounded-full hover:bg-muted"
                      >
                        <Printer className="size-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={`More actions for ${p.name}`}
                        className="flex size-8 items-center justify-center rounded-full hover:bg-muted"
                      >
                        <MoreHorizontal className="size-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Top Selling Products" action={<span className="text-xs font-bold">View All</span>}>
          <ol className="flex flex-col gap-3">
            {topSelling.map((t, i) => (
              <li key={t.name} className="flex items-center gap-4 rounded-2xl bg-muted p-3">
                <span className="flex size-9 items-center justify-center rounded-full bg-ink text-sm font-bold text-ink-foreground">
                  {i + 1}
                </span>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.sold} sold</p>
                </div>
                <span className="text-sm font-bold">{t.revenue}</span>
              </li>
            ))}
          </ol>
        </Panel>
        <Panel title="Recent Activity">
          <ol className="relative flex flex-col gap-5 border-l-2 border-border pl-5">
            {activity.map((a) => (
              <li key={a.text} className="relative">
                <span className="absolute -left-[27px] top-1 size-3 rounded-full bg-primary ring-4 ring-background" />
                <p className="text-sm font-medium">{a.text}</p>
                <p className="text-xs text-muted-foreground">{a.time}</p>
              </li>
            ))}
          </ol>
        </Panel>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {[
          { title: 'Explore Features', body: 'POS, multi-warehouse inventory and storefront studio.', cta: 'Explore Features', tone: 'ink' },
          { title: 'Monthly report ready', body: 'Your September sales ledger has been generated.', cta: 'View Full Report', tone: 'muted' },
          { title: 'Go Pro', body: 'Custom domains, staff roles and multi-branch POS.', cta: 'Upgrade Now', tone: 'primary' },
        ].map((b) => (
          <div
            key={b.title}
            className={cn(
              'flex flex-col justify-between gap-6 rounded-3xl p-6',
              b.tone === 'ink' && 'bg-ink text-ink-foreground',
              b.tone === 'muted' && 'bg-background ring-1 ring-border',
              b.tone === 'primary' && 'bg-primary text-primary-foreground',
            )}
          >
            <div>
              <h3 className="text-lg font-bold">{b.title}</h3>
              <p className="mt-1 text-sm opacity-70">{b.body}</p>
            </div>
            <button
              type="button"
              className={cn(
                'inline-flex h-9 w-fit items-center rounded-full px-4 text-xs font-bold',
                b.tone === 'ink' ? 'bg-primary text-primary-foreground' : 'bg-ink text-ink-foreground',
              )}
            >
              {b.cta}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
