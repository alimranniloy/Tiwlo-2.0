import Link from 'next/link'
import {
  ArrowRight,
  Barcode,
  Check,
  Cloud,
  Database,
  Globe,
  Headphones,
  Layers,
  Lock,
  MonitorSmartphone,
  Plus,
  RefreshCw,
  Server,
  ShieldCheck,
  Store,
  Zap,
} from 'lucide-react'
import { cn } from '@/lib/utils'

function SectionHeading({ eyebrow, title, body, invert }: { eyebrow: string; title: string; body?: string; invert?: boolean }) {
  return (
    <div className="max-w-2xl">
      <p className={cn('text-sm font-semibold uppercase tracking-widest', invert ? 'text-primary' : 'text-[#0f7a37]')}>
        {eyebrow}
      </p>
      <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-5xl">{title}</h2>
      {body && <p className={cn('mt-4 text-pretty text-lg', invert ? 'text-white/65' : 'text-muted-foreground')}>{body}</p>}
    </div>
  )
}

export function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:pt-24">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-xs font-semibold">
            <span className="size-2 rounded-full bg-primary" /> Tiwlo Cloud · Commerce · Mail · UIDs
          </span>
          <h1 className="mt-6 text-balance text-5xl font-bold leading-[1.02] tracking-tight sm:text-7xl">
            Accelerate your business with <span className="text-[#0f7a37]">Tiwlo Cloud</span>
          </h1>
          <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            The unified cloud computing and commerce platform. Deploy scalable virtual droplets, build modern online
            storefronts with omnichannel POS, and scale on a global network.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/signup"
              className="inline-flex h-12 items-center gap-2 rounded-full bg-primary px-7 text-sm font-bold text-primary-foreground transition hover:bg-primary/85"
            >
              Start free trial <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <a
              href="#products"
              className="inline-flex h-12 items-center rounded-full px-7 text-sm font-bold ring-1 ring-border transition hover:bg-muted"
            >
              Explore solutions
            </a>
          </div>
          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            {['Enterprise 99.99% SLA guarantee', 'No credit card required to start', '24/7 dedicated engineering support'].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <Check className="size-4 text-[#0f7a37]" strokeWidth={3} aria-hidden="true" /> {t}
              </li>
            ))}
          </ul>
        </div>

        <HeroPreview />
      </div>
    </section>
  )
}

function HeroPreview() {
  return (
    <div className="relative" aria-hidden="true">
      <div className="pointer-events-none absolute -right-24 -top-16 size-[440px] rounded-full border-[52px] border-primary/90" />
      <div className="relative rounded-[2rem] bg-ink p-3 shadow-2xl">
        <div className="flex items-center gap-1.5 px-3 pb-3 pt-1">
          <span className="size-2.5 rounded-full bg-white/20" />
          <span className="size-2.5 rounded-full bg-white/20" />
          <span className="size-2.5 rounded-full bg-white/20" />
          <span className="ml-3 rounded-full bg-white/10 px-3 py-1 text-[10px] text-white/60">console.tiwlo.com</span>
        </div>
        <div className="grid gap-3 rounded-[1.5rem] bg-muted p-4 sm:grid-cols-3">
          <div className="rounded-2xl bg-background p-4 sm:col-span-2">
            <p className="text-xs font-semibold text-muted-foreground">Total Sales</p>
            <p className="mt-1 text-3xl font-bold tracking-tight">$42,580</p>
            <div className="mt-4 flex h-24 items-end gap-2">
              {[40, 65, 48, 80, 62, 92, 74].map((h, i) => (
                <span key={i} className={cn('flex-1 rounded-t-md', i === 5 ? 'bg-primary' : 'bg-ink/80')} style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <div className="flex-1 rounded-2xl bg-primary p-4 text-primary-foreground">
              <Server className="size-5" />
              <p className="mt-3 text-2xl font-bold">4</p>
              <p className="text-xs opacity-70">Droplets running</p>
            </div>
            <div className="flex-1 rounded-2xl bg-background p-4">
              <Store className="size-5" />
              <p className="mt-3 text-2xl font-bold">1,284</p>
              <p className="text-xs text-muted-foreground">Products</p>
            </div>
          </div>
          <div className="rounded-2xl bg-background p-4 sm:col-span-3">
            {[
              ['web-prod-01', 'Frankfurt'],
              ['tiwimart-api', 'Singapore'],
            ].map(([n, r]) => (
              <div key={n} className="flex items-center justify-between border-b border-border py-2 text-xs last:border-0">
                <span className="font-semibold">{n}</span>
                <span className="text-muted-foreground">{r}</span>
                <span className="rounded-full bg-primary/15 px-2 py-0.5 font-semibold text-[#0f7a37]">Running</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const products = [
  { title: 'Cloud Compute', body: 'Cost-optimized instance families for web workloads, caching, and databases.', icon: Server, href: '/dashboard' },
  { title: 'Commerce Storefront', body: 'Responsive theme engine optimized for 100% Core Web Vitals performance.', icon: Store, href: '/ecommerce' },
  { title: 'Retail & POS', body: 'ESC/POS 80mm printers, barcode scanners, cash drawers and offline mode.', icon: MonitorSmartphone, href: '/ecommerce' },
  { title: 'Cloud Database', body: 'Dedicated AES-256 encryption at rest and TLS 1.3 in transit.', icon: Database, href: '/dashboard' },
  { title: 'Anycast DNS & SSL', body: 'DNS ownership verification and Let’s Encrypt certificates for apex domains.', icon: Globe, href: '/oneprofile' },
]

export function ProductsSection() {
  return (
    <section id="products" className="bg-muted/50 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Products"
          title="Everything your business runs on, in one console."
          body="From virtual servers to storefronts, POS registers and identity — each product shares one account, one bill and one dashboard."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {products.map((p, i) => (
            <Link
              key={p.title}
              href={p.href}
              className={cn(
                'group flex flex-col justify-between gap-10 rounded-3xl p-6 transition',
                i === 0 ? 'bg-ink text-ink-foreground lg:col-span-2' : 'bg-background ring-1 ring-border hover:ring-ink',
              )}
            >
              <span
                className={cn(
                  'flex size-11 items-center justify-center rounded-full',
                  i === 0 ? 'bg-primary text-primary-foreground' : 'bg-muted',
                )}
              >
                <p.icon className="size-5" aria-hidden="true" />
              </span>
              <div>
                <h3 className="text-lg font-bold">{p.title}</h3>
                <p className={cn('mt-2 text-sm leading-relaxed', i === 0 ? 'text-white/65' : 'text-muted-foreground')}>{p.body}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-bold">
                  Learn more <ArrowRight className="size-4 transition group-hover:translate-x-0.5" aria-hidden="true" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

const dropletPlans = [
  {
    name: 'Tiwlo Standard Droplet',
    tag: 'Most Popular for Stores',
    desc: 'Ideal for e-commerce storefronts, point-of-sale backends, and customer-facing web services with automated scaling.',
    specs: ['General Purpose & Web Applications', 'Up to 5 Gbps Network Bandwidth', 'Frankfurt, Singapore, New York, London, Mumbai'],
    featured: true,
  },
  {
    name: 'Tiwlo Memory-Optimized Droplet',
    tag: 'Real-Time Caching',
    desc: 'Engineered for high-volume inventory ledgers, fast Redis caching, and instantaneous order processing under heavy flash sales.',
    specs: ['High-Throughput In-Memory Workloads', 'Up to 10 Gbps Private VPC Networking', 'Frankfurt, Tokyo, Mumbai, Toronto, Sydney'],
  },
  {
    name: 'Tiwlo Isolated Enterprise Cluster',
    tag: 'Mission-Critical Scale',
    desc: 'Maximum security and performance with physical data partitioning, custom firewall governance, and strict compliance isolation.',
    specs: ['Dedicated Bare-Metal Nodes · Custom RAM/Storage Ratios', 'Dedicated Multi-Region Virtual Private Cloud', 'Global Availability across 20+ Data Center Zones'],
  },
]

export function CloudSection() {
  return (
    <section id="cloud" className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Cloud Compute"
            title="Droplets built for every workload."
            body="Sub-millisecond local NVMe storage, automated daily backups and live TLS 1.3 encryption on every instance."
          />
          <Link
            href="/dashboard"
            className="inline-flex h-12 w-fit items-center gap-2 rounded-full bg-ink px-6 text-sm font-bold text-ink-foreground transition hover:bg-ink/85"
          >
            <Plus className="size-4" aria-hidden="true" /> Deploy Tiwlo Droplet
          </Link>
        </div>
        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {dropletPlans.map((p) => (
            <article
              key={p.name}
              className={cn(
                'flex flex-col rounded-3xl p-7',
                p.featured ? 'bg-primary text-primary-foreground' : 'bg-muted',
              )}
            >
              <span
                className={cn(
                  'w-fit rounded-full px-3 py-1 text-xs font-bold',
                  p.featured ? 'bg-ink text-ink-foreground' : 'bg-background',
                )}
              >
                {p.tag}
              </span>
              <h3 className="mt-6 text-2xl font-bold tracking-tight">{p.name}</h3>
              <p className={cn('mt-3 text-sm leading-relaxed', p.featured ? 'text-primary-foreground/70' : 'text-muted-foreground')}>
                {p.desc}
              </p>
              <ul className="mt-6 flex flex-col gap-3 border-t border-current/10 pt-6">
                {p.specs.map((s) => (
                  <li key={s} className="flex items-start gap-3 text-sm font-medium">
                    <Check className="mt-0.5 size-4 shrink-0" strokeWidth={3} aria-hidden="true" /> {s}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

const commerce = [
  {
    title: 'Omnichannel Retail POS',
    body: 'Ring up sales in seconds with hardware-ready barcode scanning, thermal receipt printing, and offline IndexedDB resilience.',
    points: ['Laser barcode & QR code recognition', 'ESC/POS 80mm printer integration', 'Offline sales sync upon reconnect'],
    icon: Barcode,
  },
  {
    title: 'High-Converting Storefront Studio',
    body: 'Launch custom-branded online storefronts with responsive themes optimized for top mobile performance and speed scores.',
    points: ['Zero-code theme customizer', 'Instant search & faceted product filters'],
    icon: Store,
  },
  {
    title: 'Global Multi-Currency Checkout',
    body: 'Accept payments from customers worldwide with localized currencies, international credit cards, and digital wallets.',
    points: ['Native USD, EUR, GBP, and BDT support', 'Customer payment-method selection for order records'],
    icon: Globe,
  },
  {
    title: 'Automated Multi-Warehouse Inventory',
    body: 'Maintain unified stock counts across online storefronts, physical retail branches, and supplier warehouses.',
    points: ['Real-time stock depletion alerts', 'Multi-location batch adjustments', 'Automated supplier reorder notices'],
    icon: Layers,
  },
]

export function CommerceSection() {
  return (
    <section id="commerce" className="bg-ink py-24 text-ink-foreground">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            invert
            eyebrow="E-commerce"
            title="Sell online and in-store from one catalog."
            body="Storefront, POS, payments and inventory share the same data, so every sale updates everywhere instantly."
          />
          <Link
            href="/ecommerce"
            className="inline-flex h-12 w-fit items-center gap-2 rounded-full bg-primary px-6 text-sm font-bold text-primary-foreground transition hover:bg-primary/85"
          >
            Explore E-commerce <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </div>
        <div className="mt-12 grid gap-4 md:grid-cols-2">
          {commerce.map((c) => (
            <article key={c.title} className="rounded-3xl bg-white/5 p-7 ring-1 ring-white/10">
              <span className="flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <c.icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-6 text-xl font-bold">{c.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/65">{c.body}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {c.points.map((p) => (
                  <li key={p} className="rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold">
                    {p}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

const why = [
  { title: 'Anycast Global Edge Network', body: 'Edge routing across 20+ global regions ensures your storefront loads in under 30ms anywhere in the world.', icon: Zap },
  { title: 'Dedicated Tenant Isolation', body: 'Each store runs on an isolated data partition with encrypted storage, eliminating cross-tenant vulnerability.', icon: Lock },
  { title: 'Automated SSL & DNS Engine', body: 'Verify custom-domain ownership with DNS records and request SSL once the domain points to Tiwlo.', icon: Globe },
  { title: 'Zero-Interruption Rolling Updates', body: 'Deploy code updates, database migrations, and schema changes without customer downtime.', icon: RefreshCw },
  { title: 'High-Availability 99.99% SLA', body: 'Automated health monitoring, self-healing containers, and multi-cloud failover.', icon: ShieldCheck },
  { title: '24/7 Engineering Support', body: 'Direct access to cloud and e-commerce engineers via live chat, tickets, and phone.', icon: Headphones },
]

const comparison = [
  ['Storefront & Omnichannel POS Integration', 'Separate vendors', 'Unified Native'],
  ['Multi-Tenant Database Isolation', 'Shared tables', 'Hardware Isolated'],
  ['Automated Global SSL & Anycast DNS', 'Manual setup', 'Zero-touch Automated'],
  ['Dedicated Cloud Compute Instances', 'Separate vendors', 'One Single Console'],
  ['Deployment Time to First Sale', 'Days / Weeks', 'Under 5 minutes'],
]

export function WhySection() {
  return (
    <section id="why" className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading eyebrow="Why Tiwlo" title="Infrastructure you never have to think about." />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {why.map((w) => (
            <article key={w.title} className="rounded-3xl bg-muted p-6">
              <w.icon className="size-6" aria-hidden="true" />
              <h3 className="mt-5 font-bold">{w.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{w.body}</p>
            </article>
          ))}
        </div>

        <div className="mt-16 overflow-hidden rounded-3xl ring-1 ring-border">
          <div className="bg-ink px-6 py-5 text-ink-foreground">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary">Platform Comparison</p>
            <h3 className="mt-1 text-xl font-bold">Traditional Fragmented Stack vs. Tiwlo Unified Cloud</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead>
                <tr className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-6 py-4 font-semibold">Feature</th>
                  <th className="px-6 py-4 font-semibold">Traditional Hosting</th>
                  <th className="px-6 py-4 font-semibold">Tiwlo Platform</th>
                </tr>
              </thead>
              <tbody>
                {comparison.map(([f, t, w]) => (
                  <tr key={f} className="border-b border-border last:border-0">
                    <td className="px-6 py-4 font-semibold">{f}</td>
                    <td className="px-6 py-4 text-muted-foreground">{t}</td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1 text-xs font-bold text-[#0f7a37]">
                        <Check className="size-3.5" strokeWidth={3} aria-hidden="true" /> {w}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  )
}

const faqs = [
  {
    q: 'How quickly can I set up and launch an online store with Tiwlo?',
    a: 'You can launch a fully functional, mobile-optimized online store in less than 5 minutes. Select your account type, pick a modern theme, add your first products, and start accepting payments immediately.',
  },
  {
    q: 'Can I connect my own custom domain with automated SSL?',
    a: 'Growth, Pro, and Enterprise accounts can connect a custom domain. Add the requested TXT ownership record and point its A record to the Tiwlo server; after verification, the system can provision SSL.',
  },
  {
    q: 'How does Tiwlo’s isolated multi-tenant database protect my business data?',
    a: 'Tiwlo provisions isolated multi-tenant databases for each store. Your customer records, transactions, inventory, and analytics are stored separately and encrypted with dedicated AES-256 keys.',
  },
  {
    q: 'Can I use the Omnichannel POS register without an internet connection?',
    a: 'Yes. The Tiwlo POS terminal features offline caching via IndexedDB. Once reconnected, transactions synchronize automatically with the cloud.',
  },
  {
    q: 'How does Tiwlo Cloud Compute droplets work?',
    a: 'Tiwlo Cloud droplets are high-availability virtual compute instances deployed across Frankfurt, Singapore, New York, London and Mumbai. Provision, scale, and monitor them from the unified Tiwlo console.',
  },
  {
    q: 'Are there any hidden transaction fees or setup charges?',
    a: 'No. Tiwlo has transparent, predictable pricing. External payment gateway processing is not enabled in the current deployment.',
  },
]

export function FaqSection() {
  return (
    <section id="faq" className="bg-muted/50 py-24">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
        <SectionHeading eyebrow="FAQ" title="Questions, answered." body="Can’t find what you need? Our engineers are available 24/7." />
        <div className="flex flex-col gap-3 lg:col-span-2">
          {faqs.map((f, i) => (
            <details key={f.q} open={i === 0} className="group rounded-2xl bg-background p-5 ring-1 ring-border open:ring-ink">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-bold">
                {f.q}
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted transition group-open:rotate-45 group-open:bg-primary">
                  <Plus className="size-4" aria-hidden="true" />
                </span>
              </summary>
              <p className="mt-3 pr-12 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}

export function CtaSection() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-primary px-6 py-16 text-center text-primary-foreground sm:px-16">
          <Cloud className="mx-auto size-10" aria-hidden="true" />
          <h2 className="mx-auto mt-6 max-w-2xl text-balance text-4xl font-bold tracking-tight sm:text-5xl">
            Ready to build on Tiwlo?
          </h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/signup" className="inline-flex h-12 items-center gap-2 rounded-full bg-ink px-7 text-sm font-bold text-ink-foreground transition hover:bg-ink/85">
              Start free trial <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <a href="#cloud" className="inline-flex h-12 items-center rounded-full bg-background/30 px-7 text-sm font-bold transition hover:bg-background/50">
              View plans & pricing
            </a>
          </div>
          <ul className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm font-semibold">
            {['No setup fees', 'Instant automated SSL', '24/7 technical support'].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <Check className="size-4" strokeWidth={3} aria-hidden="true" /> {t}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
