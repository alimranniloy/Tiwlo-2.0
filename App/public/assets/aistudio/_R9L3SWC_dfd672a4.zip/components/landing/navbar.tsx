'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import { Logo } from '@/components/brand/logo'

const links = [
  { href: '#products', label: 'Solutions' },
  { href: '#cloud', label: 'Cloud Compute' },
  { href: '#commerce', label: 'Commerce' },
  { href: '#why', label: 'Why Tiwlo' },
  { href: '#faq', label: 'FAQ' },
]

export function LandingNavbar() {
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-8 px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="rounded-full px-3.5 py-2 text-sm font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="ml-auto hidden items-center gap-2 md:flex">
          <Link href="/login" className="rounded-full px-4 py-2 text-sm font-bold transition hover:bg-muted">
            Sign in
          </Link>
          <Link href="/dashboard" className="rounded-full bg-ink px-5 py-2.5 text-sm font-bold text-ink-foreground transition hover:bg-ink/85">
            Open Console
          </Link>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={open}
          className="ml-auto flex size-10 items-center justify-center rounded-full hover:bg-muted md:hidden"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      {open && (
        <nav aria-label="Mobile" className="flex flex-col gap-1 border-t border-border px-4 py-4 md:hidden">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm font-medium hover:bg-muted">
              {l.label}
            </a>
          ))}
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Link href="/login" className="rounded-full py-2.5 text-center text-sm font-bold ring-1 ring-border">
              Sign in
            </Link>
            <Link href="/signup" className="rounded-full bg-primary py-2.5 text-center text-sm font-bold text-primary-foreground">
              Start free trial
            </Link>
          </div>
        </nav>
      )}
    </header>
  )
}
