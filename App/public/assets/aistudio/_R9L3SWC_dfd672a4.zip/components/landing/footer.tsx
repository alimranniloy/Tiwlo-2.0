import { Logo } from '@/components/brand/logo'

const columns = [
  {
    title: 'Products',
    links: ['E-Commerce Storefront', 'Cloud Infrastructure', 'Omnichannel POS Register', 'Multi-Tenant Database', 'Custom Domain DNS & SSL'],
  },
  {
    title: 'Solutions',
    links: ['Fast-Growing Startups', 'Retail & Multi-Branch POS', 'Wholesale & Inventory', 'Custom Domain Hosting', 'Enterprise Security'],
  },
  {
    title: 'Resources',
    links: ['Platform Documentation', 'Developer REST APIs', 'System Uptime Status', 'Pricing Calculator', 'Changelog & Updates'],
  },
  {
    title: 'Support & Trust',
    links: ['Live Engineer Chat', 'Security & Privacy Policy', 'Terms of Service', 'SLA Guarantee (99.99%)'],
  },
]

export function LandingFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <Logo inverted />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/60">
              The unified cloud computing and commerce platform for modern businesses.
            </p>
          </div>
          {columns.map((c) => (
            <div key={c.title}>
              <h3 className="text-sm font-bold">{c.title}</h3>
              <ul className="mt-4 flex flex-col gap-3">
                {c.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-sm text-white/60 transition hover:text-white">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-xs text-white/50 sm:flex-row sm:items-center sm:justify-between">
          <p>{'© 2026 Tiwlo Ltd. All rights reserved.'}</p>
          <p>English (United States)</p>
        </div>
      </div>
    </footer>
  )
}
