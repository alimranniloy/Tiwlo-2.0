import {
  ArrowUpRight,
  Container,
  Cpu,
  Database,
  Gauge,
  Globe,
  HardDrive,
  KeyRound,
  MoreHorizontal,
  Network,
  PanelsTopLeft,
  Plus,
  Server,
  Shield,
  Terminal,
} from 'lucide-react'
import { TrendArea } from '@/components/shell/charts'
import { Panel, PillButton, StatCard, StatusPill } from '@/components/shell/primitives'

const droplets = [
  { name: 'web-prod-01', spec: '2 vCPU · 4 GB · 80 GB NVMe', ip: '159.89.12.44', region: 'Frankfurt', status: 'Running', created: '12 Feb 2026' },
  { name: 'tiwimart-api', spec: '4 vCPU · 8 GB · 160 GB NVMe', ip: '143.198.77.10', region: 'Singapore', status: 'Running', created: '03 Jan 2026' },
  { name: 'redis-cache', spec: '2 vCPU · 16 GB · Memory-Opt', ip: '178.62.31.205', region: 'London', status: 'Running', created: '22 Dec 2025' },
  { name: 'staging-box', spec: '1 vCPU · 1 GB · 25 GB NVMe', ip: '68.183.90.3', region: 'New York', status: 'Stopped', created: '30 Nov 2025' },
]

const usage = [
  { label: 'Mon', cpu: 32, bandwidth: 18 },
  { label: 'Tue', cpu: 44, bandwidth: 26 },
  { label: 'Wed', cpu: 38, bandwidth: 22 },
  { label: 'Thu', cpu: 61, bandwidth: 35 },
  { label: 'Fri', cpu: 55, bandwidth: 41 },
  { label: 'Sat', cpu: 72, bandwidth: 48 },
  { label: 'Sun', cpu: 58, bandwidth: 39 },
]

const createNew = [
  { label: 'Droplets', desc: 'Virtual servers', icon: Server },
  { label: 'Kubernetes', desc: 'Managed clusters', icon: Container },
  { label: 'Volumes', desc: 'Add block storage', icon: HardDrive },
  { label: 'Spaces', desc: 'Object Storage · S3 compatible', icon: Database },
  { label: 'Static websites', desc: 'Deploy from Git', icon: Globe },
  { label: 'TPanel', desc: 'Server control panel', icon: PanelsTopLeft },
]

const images = ['Ubuntu 22.04 LTS', 'Debian 12', 'AlmaLinux 9', 'CentOS 8']

const quickAccess = [
  { label: 'Domains', desc: 'Manage your domains', icon: Globe },
  { label: 'Firewall', desc: 'Control your traffic', icon: Shield },
  { label: 'SSH Keys', desc: 'Manage your keys', icon: KeyRound },
  { label: 'API Tokens', desc: 'Access the API', icon: Terminal },
]

const services = [
  { name: 'Droplets', status: 'Operational' },
  { name: 'Networking', status: 'Operational' },
  { name: 'Block Storage', status: 'Operational' },
  { name: 'Kubernetes', status: 'Degraded' },
  { name: 'Anycast DNS', status: 'Operational' },
]

const meters = [
  { label: 'Memory', used: 18, total: 32, unit: 'GB' },
  { label: 'Storage', used: 265, total: 500, unit: 'GB' },
  { label: 'Bandwidth', used: 1.8, total: 4, unit: 'TB' },
]

export function CloudOverview() {
  return (
    <div className="flex flex-col gap-8">
      <section className="relative overflow-hidden rounded-3xl bg-ink p-6 text-ink-foreground sm:p-10">
        <div className="relative z-10 max-w-xl">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">Good morning</p>
          <h1 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-5xl">Welcome back, Rahim</h1>
          <p className="mt-3 text-pretty text-white/70">
            Deploy scalable virtual droplets across Frankfurt, Singapore, New York, London and Mumbai — all from one
            console.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <PillButton variant="primary">
              <Plus className="size-4" aria-hidden="true" /> Create Droplet
            </PillButton>
            <button
              type="button"
              className="inline-flex h-10 items-center gap-2 rounded-full bg-white/10 px-5 text-sm font-bold ring-1 ring-white/15 transition hover:bg-white/15"
            >
              Open TPanel <ArrowUpRight className="size-4" aria-hidden="true" />
            </button>
          </div>
        </div>
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-24 size-[420px] rounded-full border-[48px] border-primary/90"
        />
        <div aria-hidden="true" className="pointer-events-none absolute -bottom-16 right-48 size-40 rounded-full bg-primary/20" />
      </section>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Droplets" value="4" hint="3 running · 1 stopped" icon={Server} tone="ink" />
        <StatCard label="Total vCPUs" value="9" hint="Across 4 regions" icon={Cpu} />
        <StatCard label="Total Storage" value="265 GB" hint="NVMe + volumes" icon={HardDrive} />
        <StatCard label="Total Bandwidth" value="1.8 TB" hint="This billing cycle" icon={Network} tone="primary" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel
          title="Workload Performance Overview"
          className="lg:col-span-2"
          action={
            <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="size-2 rounded-full bg-[#1ed760]" /> CPU %
              </span>
              <span className="flex items-center gap-1.5">
                <span className="size-2 rounded-full bg-[#121212]" /> Bandwidth GB
              </span>
            </div>
          }
        >
          <TrendArea
            data={usage}
            keys={[
              { key: 'cpu', color: '#1ed760', label: 'CPU %' },
              { key: 'bandwidth', color: '#121212', label: 'Bandwidth GB' },
            ]}
          />
        </Panel>

        <Panel title="Usage Overview" action={<Gauge className="size-5 text-muted-foreground" aria-hidden="true" />}>
          <ul className="flex flex-col gap-6">
            {meters.map((m) => {
              const pct = Math.round((m.used / m.total) * 100)
              return (
                <li key={m.label}>
                  <div className="flex items-baseline justify-between text-sm">
                    <span className="font-semibold">{m.label}</span>
                    <span className="text-muted-foreground">
                      {m.used} / {m.total} {m.unit}
                    </span>
                  </div>
                  <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="mt-1.5 text-xs text-muted-foreground">{pct}% used</p>
                </li>
              )
            })}
          </ul>
        </Panel>
      </div>

      <Panel
        id="droplets"
        title="My Droplets"
        action={
          <PillButton className="h-9 px-4">
            <Plus className="size-4" aria-hidden="true" /> Add Droplet
          </PillButton>
        }
      >
        <div className="-mx-5 overflow-x-auto sm:-mx-6">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead>
              <tr className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                <th className="px-5 pb-3 font-semibold sm:px-6">Name</th>
                <th className="pb-3 font-semibold">IP Address</th>
                <th className="pb-3 font-semibold">Region</th>
                <th className="pb-3 font-semibold">Status</th>
                <th className="pb-3 font-semibold">Created</th>
                <th className="px-5 pb-3 text-right font-semibold sm:px-6">Actions</th>
              </tr>
            </thead>
            <tbody>
              {droplets.map((d) => (
                <tr key={d.name} className="border-b border-border last:border-0">
                  <td className="px-5 py-4 sm:px-6">
                    <div className="flex items-center gap-3">
                      <span className="flex size-10 items-center justify-center rounded-xl bg-muted">
                        <Server className="size-4" aria-hidden="true" />
                      </span>
                      <div>
                        <p className="font-semibold">{d.name}</p>
                        <p className="text-xs text-muted-foreground">{d.spec}</p>
                      </div>
                    </div>
                  </td>
                  <td className="font-mono text-xs">{d.ip}</td>
                  <td>{d.region}</td>
                  <td>
                    <StatusPill status={d.status} />
                  </td>
                  <td className="text-muted-foreground">{d.created}</td>
                  <td className="px-5 sm:px-6">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        className="h-8 rounded-full bg-muted px-3 text-xs font-bold transition hover:bg-secondary"
                      >
                        Login to TPanel
                      </button>
                      <button
                        type="button"
                        aria-label={`More actions for ${d.name}`}
                        className="flex size-8 items-center justify-center rounded-full hover:bg-muted"
                      >
                        <MoreHorizontal className="size-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel id="create" title="Create New" className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {createNew.map((c) => (
              <button
                key={c.label}
                type="button"
                className="group flex flex-col items-start gap-4 rounded-2xl bg-muted p-4 text-left transition hover:bg-ink hover:text-ink-foreground"
              >
                <span className="flex size-10 items-center justify-center rounded-full bg-background text-foreground transition group-hover:bg-primary group-hover:text-primary-foreground">
                  <c.icon className="size-4" aria-hidden="true" />
                </span>
                <span>
                  <span className="block text-sm font-bold">{c.label}</span>
                  <span className="block text-xs text-muted-foreground group-hover:text-white/60">{c.desc}</span>
                </span>
              </button>
            ))}
          </div>
        </Panel>

        <Panel title="Service Status" action={<span className="text-xs font-semibold text-muted-foreground">View status</span>}>
          <ul className="flex flex-col divide-y divide-border">
            {services.map((s) => (
              <li key={s.name} className="flex items-center justify-between py-3 first:pt-0 last:pb-0">
                <span className="text-sm font-medium">{s.name}</span>
                <StatusPill status={s.status} />
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel id="images" title="Popular Images">
          <div className="grid grid-cols-2 gap-3">
            {images.map((img) => (
              <div key={img} className="flex items-center gap-3 rounded-2xl bg-muted p-3">
                <span className="flex size-10 items-center justify-center rounded-full bg-ink text-xs font-bold text-ink-foreground">
                  {img.slice(0, 2)}
                </span>
                <span className="text-sm font-semibold">{img}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel id="domains" title="Quick Access">
          <div className="grid grid-cols-2 gap-3">
            {quickAccess.map((q) => (
              <button
                key={q.label}
                type="button"
                className="flex items-center gap-3 rounded-2xl p-3 text-left ring-1 ring-border transition hover:bg-muted"
              >
                <span className="flex size-10 items-center justify-center rounded-full bg-primary/15 text-[#0f7a37]">
                  <q.icon className="size-4" aria-hidden="true" />
                </span>
                <span>
                  <span className="block text-sm font-bold">{q.label}</span>
                  <span className="block text-xs text-muted-foreground">{q.desc}</span>
                </span>
              </button>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}
