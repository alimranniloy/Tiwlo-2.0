import Link from 'next/link'
import { cn } from '@/lib/utils'

export function Logo({
  className,
  inverted = false,
  href = '/',
  suffix,
}: {
  className?: string
  inverted?: boolean
  href?: string
  suffix?: string
}) {
  return (
    <Link href={href} className={cn('flex items-center gap-2', className)} aria-label="Tiwlo home">
      <span
        className={cn(
          'flex size-8 items-center justify-center rounded-full',
          inverted ? 'bg-primary text-primary-foreground' : 'bg-ink text-ink-foreground',
        )}
      >
        <svg viewBox="0 0 24 24" className="size-4" fill="currentColor" aria-hidden="true">
          <path d="M12 2.5c3.6 4.3 6.5 8 6.5 11.5a6.5 6.5 0 1 1-13 0c0-3.5 2.9-7.2 6.5-11.5Z" />
        </svg>
      </span>
      <span className={cn('text-lg font-bold tracking-tight', inverted ? 'text-ink-foreground' : 'text-foreground')}>
        Tiwlo
        {suffix && (
          <span className={cn('ml-1.5 font-medium', inverted ? 'text-white/50' : 'text-muted-foreground')}>{suffix}</span>
        )}
      </span>
    </Link>
  )
}
